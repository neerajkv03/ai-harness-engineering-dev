import "./style.css"
import { StrictMode } from "react"
import { createRoot } from "react-dom/client"
import App from "./App.tsx"

// Theme follows the system preference via the `.dark` class (no manual toggle; see DESIGN.md §2).
const prefersDark = window.matchMedia("(prefers-color-scheme: dark)")
const applyTheme = () => document.documentElement.classList.toggle("dark", prefersDark.matches)
applyTheme()
prefersDark.addEventListener("change", applyTheme)

createRoot(document.getElementById("app")!).render(
  <StrictMode>
    <App />
  </StrictMode>,
)
